#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
matches = []

for path in root.rglob("*"):
    if path.is_file() and path.suffix in {".yaml", ".yml", ".tf", ".py", ".sh", ".json"}:
        text = path.read_text(encoding="utf-8", errors="ignore")
        for line_number, line in enumerate(text.splitlines(), start=1):
            if "________" in line:
                matches.append((path, line_number, line.strip()))

if matches:
    print("Unfilled blanks found:")
    for path, line_number, line in matches:
        print(f"{path}:{line_number}: {line}")
    sys.exit(1)

print("No blanks found.")
