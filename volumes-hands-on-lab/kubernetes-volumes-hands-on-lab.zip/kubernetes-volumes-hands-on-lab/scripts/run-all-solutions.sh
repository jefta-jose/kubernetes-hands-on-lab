#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
namespace="volumes-lab"

kubectl create namespace "${namespace}" --dry-run=client -o yaml | kubectl apply -f -

run_exercise() {
  local exercise_dir="$1"
  echo
  echo "=== Applying ${exercise_dir} ==="
  kubectl apply -f "${repo_root}/exercises/${exercise_dir}/solution/"
  sleep 2
}

cleanup_names() {
  kubectl delete pod volume-restart-demo shared-volume-demo init-volume-demo configmap-volume-demo configmap-subpath-demo \
    secret-volume-demo projected-volume-demo pvc-writer hostpath-writer hostpath-reader \
    --namespace "${namespace}" --ignore-not-found
}

cleanup_names

run_exercise "01-emptydir-container-restart"
kubectl wait --for=condition=Ready pod/volume-restart-demo -n "${namespace}" --timeout=90s
kubectl delete pod volume-restart-demo -n "${namespace}" --ignore-not-found

run_exercise "02-shared-volume"
kubectl wait --for=condition=Ready pod/shared-volume-demo -n "${namespace}" --timeout=90s
kubectl delete pod shared-volume-demo -n "${namespace}" --ignore-not-found

run_exercise "03-init-container"
kubectl wait --for=condition=Ready pod/init-volume-demo -n "${namespace}" --timeout=90s
kubectl delete pod init-volume-demo -n "${namespace}" --ignore-not-found

run_exercise "04-configmap-volume"
kubectl wait --for=condition=Ready pod/configmap-volume-demo -n "${namespace}" --timeout=90s
kubectl delete pod configmap-volume-demo configmap-subpath-demo -n "${namespace}" --ignore-not-found
kubectl delete configmap web-config -n "${namespace}" --ignore-not-found

run_exercise "05-secret-volume-permissions"
kubectl wait --for=condition=Ready pod/secret-volume-demo -n "${namespace}" --timeout=90s
kubectl delete pod secret-volume-demo -n "${namespace}" --ignore-not-found
kubectl delete secret application-credentials -n "${namespace}" --ignore-not-found

run_exercise "06-projected-downward-api"
kubectl wait --for=condition=Ready pod/projected-volume-demo -n "${namespace}" --timeout=90s
kubectl delete pod projected-volume-demo -n "${namespace}" --ignore-not-found
kubectl delete configmap projected-config -n "${namespace}" --ignore-not-found
kubectl delete secret projected-secret -n "${namespace}" --ignore-not-found

run_exercise "07-persistent-volume-claim"
kubectl wait --for=condition=Ready pod/pvc-writer -n "${namespace}" --timeout=120s
kubectl delete pod pvc-writer -n "${namespace}" --ignore-not-found
kubectl delete pvc lab-data -n "${namespace}" --ignore-not-found

run_exercise "08-hostpath-safety"
kubectl wait --for=condition=Ready pod/hostpath-writer -n "${namespace}" --timeout=90s
kubectl wait --for=condition=Ready pod/hostpath-reader -n "${namespace}" --timeout=90s
kubectl delete pod hostpath-writer hostpath-reader -n "${namespace}" --ignore-not-found

run_exercise "09-final-challenge"
kubectl rollout status deployment/volume-lab-web -n "${namespace}" --timeout=120s

echo
echo "All solution exercises were applied successfully."
echo "The final challenge remains running."
echo "Use ./scripts/cleanup-all.sh when finished."
