#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
failed=0

while IFS= read -r -d '' file; do
  if grep -q "________" "${file}"; then
    echo "FAIL: placeholder found in solution: ${file}"
    failed=1
    continue
  fi

  echo "Validating ${file#${repo_root}/}"
  if ! kubectl apply --dry-run=client -f "${file}" >/dev/null; then
    echo "FAIL: ${file}"
    failed=1
  fi
done < <(find "${repo_root}/exercises" -path "*/solution/*.yaml" -print0 | sort -z)

if [[ "${failed}" -ne 0 ]]; then
  echo "One or more solution manifests failed validation."
  exit 1
fi

echo "All solution manifests passed client-side validation."
